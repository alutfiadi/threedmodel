sap.ui.define([
	"threedmodel/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
